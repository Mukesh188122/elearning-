const { request } = require("express");



const path = require("path");
const Register = require('./models/registers');

const express = require("express");
const app = express(); 
app.use(express.urlencoded({ extended: true }))


require("./db/conn");
const port = process.env.PORT || 3000;
const static_path = path.join(__dirname, "../public");
//const views_path = path.join(__dirname, "../views");

app.use(express.json());
app.use(express.urlencoded({extended:false}));

//app.use(express.static(static_path));
//app.set("view engine", "hbs");

//app.set('views',path.join(__dirname,'views'));




app.get("/", (req, res) => {
    res.send("ffff");

});
app.post("/register", async(req, res) =>{
   try {
       console.log(req.body.login);
       res.send(req.body.name)
       var myData = new Register(req.body);
        
       await myData.save()

   } catch (error) {
     res.status(400).send(error)
   }

})


app.listen(port, () =>  {
    console.log(`server is running at port no ${port}` );
   
}) 